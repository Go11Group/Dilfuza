package model

type Course struct {
	Id    string
	Name  string
	Field string
}
