package model

type User struct {
	ID     string
	Name   string
	Age    int
	Gender string
	Course string
}

